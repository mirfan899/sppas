Downloaded from: 

- http://pypi.python.org/pypi/Markdown
- https://pypi.python.org/pypi/Pygments
