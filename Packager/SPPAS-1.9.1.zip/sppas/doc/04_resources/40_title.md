# Resources for Automatic Annotations
