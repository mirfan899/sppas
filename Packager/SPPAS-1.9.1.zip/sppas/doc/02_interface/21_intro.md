## Introduction

The current chapter describes how to use SPPAS with the Graphical User 
Interface (GUI) and  with the Command-line User Interface (CLI).
Each feature implemented in SPPAS corresponds to a program that can
be invoked by the GUI or the CLI.
