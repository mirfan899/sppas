## About this documentation

This documentation will assume that you are using a relatively recent version 
of SPPAS. There's no reason not to download the latest version whenever 
released: it's easy and fast!

**Any and all constructive comments are welcome.**
