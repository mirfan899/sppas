#!/usr/bin python
"""

:author:       Brigitte Bigi
:date:         2017-July-13
:contact:      brigitte.bigi@gmail.com
:license:      GPL, v3
:copyright:    Copyright (C) 2017 Brigitte Bigi

:summary:      Simple script to print Hello World.

"""

if __name__ == '__main__':
    print("Hello world!")
