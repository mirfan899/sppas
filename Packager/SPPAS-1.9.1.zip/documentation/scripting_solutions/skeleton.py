#!/usr/bin python
"""

:author:       Fix Me
:date:         Now
:contact:      me@me.org
:license:      GPL, v3
:copyright:    Copyright (C) 2017  Fixme

:summary:      This is the skeleton of a python script.

"""
import os
import sys
import codecs


# ----------------------------------------------------------------------------
# Global variables
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# Functions
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# This is the python entry point:
if __name__ == '__main__':
    pass
