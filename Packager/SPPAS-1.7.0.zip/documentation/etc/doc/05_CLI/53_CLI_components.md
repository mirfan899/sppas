##Programs to execute a GUI


Each program opens a frame.
The option `-i` allows to add a file in the frame;
it can be added as many times as wanted.

THIS DOCUMENTATION IS TO DO...
Any help is welcome!!!


###sppasgui.py


###dataroamer.py


###wavplayer.py


###iputranscriber.py


###dataeditor.py


###datafilter.py


###stats.py

