##Southern Min (or Min Nan) resources

*(C) Laboratoire Parole et Langage, Aix-en-Provence, France.*

We address special thanks to S-F Wang for giving us access to the corpus.

>**S-F Wang, J. Fon** (2013).
>*A Taiwan Southern Min spontaneous speech corpus for discourse prosody*,
>Proceedings of Tools ans Resources for the Analysis of Speech Prosody, Aix-en-Provence, France, 
>Eds B. Bigi and D. Hirst, ISBN: 978-2-7466-6443-2, pp. 20-23. 

