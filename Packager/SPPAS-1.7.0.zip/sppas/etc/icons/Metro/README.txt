Artist: dAKirby309 (Michael)
Iconset Homepage: http://dakirby309.deviantart.com/gallery/#/d4n4w3q
License: CC Attribution-Noncommercial 4.0
Commercial usage: Not allowed
